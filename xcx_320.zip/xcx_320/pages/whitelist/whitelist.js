Page({
  data: {
    competitions: [
      {
        id: 1,
        title: '2024年春季少儿创意绘画大赛',
        image: '/assets/work1.png',
        description: '面向5-12岁儿童的创意绘画比赛，鼓励孩子们通过艺术表达自己对世界的理解。参赛作品将由专业评委评选，优秀作品将获得展出机会。',
        deadline: '2024-06-30',
        status: '报名中'
      },
      {
        id: 2,
        title: '青少年科技创新挑战赛',
        image: '/assets/work2.png',
        description: '激发青少年对科学技术的兴趣和创新精神，培养实践能力和团队协作精神。比赛分为初中组和高中组，涵盖机器人、编程、人工智能等多个领域。',
        deadline: '2024-07-15',
        status: '即将开始'
      },
      {
        id: 3,
        title: '全国中小学生数字艺术设计大赛',
        image: '/assets/logo.png',
        description: '结合数字技术与艺术创作，面向全国中小学生。参赛者可以提交数字绘画、3D模型、动画短片等作品，展示数字时代的创意与想象力。',
        deadline: '2024-08-20',
        status: '筹备中'
      },
      {
        id: 4,
        title: '儿童创意编程大赛',
        image: '/assets/work1.png',
        description: '专为6-15岁儿童设计的编程比赛，旨在培养孩子们的逻辑思维和创造力。参赛者可以使用Scratch等儿童友好的编程工具，创建互动故事、游戏或动画。',
        deadline: '2024-09-10',
        status: '筹备中'
      }
    ]
  },

  onLoad: function() {
    // 页面加载时的逻辑
  },

  // 查看比赛详情
  viewCompetitionDetail: function(e) {
    const id = e.currentTarget.dataset.id;
    const competition = this.data.competitions.find(item => item.id === id);
    
    // 可以将比赛信息传递到详情页，或者在当前页面展示详情
    wx.showModal({
      title: competition.title,
      content: competition.description + '\n\n截止日期: ' + competition.deadline + '\n状态: ' + competition.status,
      showCancel: false,
      confirmText: '我知道了'
    });
  }
})