// pages/login/login.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    username: '',
    password: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },
  
  // 输入用户名
  inputUsername(e) {
    this.setData({
      username: e.detail.value
    })
  },
  
  // 输入密码
  inputPassword(e) {
    this.setData({
      password: e.detail.value
    })
  },
  
  // 登录按钮点击
  login() {
    const { username, password } = this.data;
    if (!username || !password) {
      wx.showToast({
        title: '请输入用户名和密码',
        icon: 'none'
      });
      return;
    }
    
    wx.showLoading({
      title: '登录中...'
    });
    
    // 调用云函数进行登录验证
    wx.cloud.callFunction({
      name: 'login',
      data: {
        username,
        password
      },
      success: res => {
        wx.hideLoading();
        const { code, message, data } = res.result;
        
        if (code === 200 && data) {
          // 登录成功，保存用户信息
          const userInfo = {
            username: data.username,
            role: data.role,
            openid: data.openid
          };
          
          // 保存用户信息到本地存储
          wx.setStorageSync('userInfo', userInfo);
          
          wx.showToast({
            title: '登录成功',
            icon: 'success'
          });
          
          // 登录成功后跳转到首页
          setTimeout(() => {
            wx.switchTab({
              url: '/pages/index/index'
            });
          }, 1500);
        } else {
          // 登录失败
          wx.showToast({
            title: message || '登录失败',
            icon: 'none'
          });
        }
      },
      fail: err => {
        wx.hideLoading();
        console.error('调用登录云函数失败', err);
        wx.showToast({
          title: '登录失败，请检查网络或云环境配置',
          icon: 'none'
        });
      }
    });
  },
  
  // 忘记密码
  forgotPassword() {
    wx.showToast({
      title: '忘记密码功能开发中',
      icon: 'none'
    });
  },
  
  // 注册账号
  register() {
    const { username, password } = this.data;
    if (!username || !password) {
      wx.showToast({
        title: '请输入用户名和密码',
        icon: 'none'
      });
      return;
    }
    
    // 简单的密码验证
    if (password.length < 6) {
      wx.showToast({
        title: '密码长度不能少于6位',
        icon: 'none'
      });
      return;
    }
    
    wx.showLoading({
      title: '注册中...'
    });
    
    // 调用云函数进行注册
    wx.cloud.callFunction({
      name: 'login', // 复用login云函数，它已经包含注册逻辑
      data: {
        username,
        password,
        isRegister: true // 标记为注册请求
      },
      success: res => {
        wx.hideLoading();
        const { code, message, data } = res.result;
        
        if (code === 200 && data) {
          // 注册成功，保存用户信息
          const userInfo = {
            username: data.username,
            role: data.role,
            openid: data.openid
          };
          
          // 保存用户信息到本地存储
          wx.setStorageSync('userInfo', userInfo);
          
          wx.showToast({
            title: '注册成功',
            icon: 'success'
          });
          
          // 注册成功后跳转到首页
          setTimeout(() => {
            wx.switchTab({
              url: '/pages/index/index'
            });
          }, 1500);
        } else {
          // 注册失败
          wx.showToast({
            title: message || '注册失败',
            icon: 'none'
          });
        }
      },
      fail: err => {
        wx.hideLoading();
        console.error('调用注册云函数失败', err);
        wx.showToast({
          title: '注册失败，请检查网络或云环境配置',
          icon: 'none'
        });
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})