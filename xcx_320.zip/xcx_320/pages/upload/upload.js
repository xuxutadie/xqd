// pages/upload/upload.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    title: '',
    description: '',
    categoryIndex: 0,
    categories: ['图片', '书籍', '视频', 'AI'],
    tempFilePath: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },
  
  // 输入标题
  inputTitle(e) {
    this.setData({
      title: e.detail.value
    });
  },
  
  // 输入描述
  inputDescription(e) {
    this.setData({
      description: e.detail.value
    });
  },
  
  // 选择类别
  bindCategoryChange(e) {
    this.setData({
      categoryIndex: e.detail.value
    });
  },
  
  // 选择图片
  chooseImage() {
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        this.setData({
          tempFilePath: res.tempFilePaths[0]
        });
      }
    });
  },
  
  // 上传作品
  uploadWork() {
    const { title, description, categoryIndex, categories, tempFilePath } = this.data;
    
    if (!title) {
      wx.showToast({
        title: '请输入作品标题',
        icon: 'none'
      });
      return;
    }
    
    if (!tempFilePath) {
      wx.showToast({
        title: '请上传作品图片',
        icon: 'none'
      });
      return;
    }
    
    wx.showLoading({
      title: '上传中...'
    });
    
    // 检查云开发是否已初始化
    if (!wx.cloud) {
      wx.hideLoading();
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用云开发功能，请升级到最新微信版本后重试。',
        showCancel: false
      });
      return;
    }
    
    // 先将图片上传到云存储
    const cloudPath = `works/${Date.now()}-${Math.floor(Math.random() * 1000)}${tempFilePath.match(/\.[^.]+?$/)[0]}`;
    
    wx.cloud.uploadFile({
      cloudPath,
      filePath: tempFilePath,
      success: res => {
        // 图片上传成功后，调用云函数保存作品信息
        const fileID = res.fileID;
        
        wx.cloud.callFunction({
          name: 'uploadWork',
          data: {
            title,
            description,
            category: categories[categoryIndex],
            fileID
          },
          success: result => {
            const { code, message } = result.result;
            
            wx.hideLoading();
            
            if (code === 200) {
              wx.showToast({
                title: '上传成功',
                icon: 'success'
              });
              
              // 上传成功后跳转到作品页
              setTimeout(() => {
                wx.navigateTo({
                  url: '/pages/works/works'
                });
              }, 1500);
            } else {
              wx.showToast({
                title: message || '上传失败',
                icon: 'none'
              });
            }
          },
          fail: err => {
            console.error('调用云函数失败', err);
            wx.hideLoading();
            wx.showModal({
              title: '云函数调用失败',
              content: '请确认云函数已正确部署，并且云环境已正确配置。',
              showCancel: false
            });
          }
        });
      },
      fail: err => {
        console.error('上传图片失败', err);
        wx.hideLoading();
        
        // 检查错误码，提供更友好的错误提示
        if (err.errCode === -601034) {
          wx.showModal({
            title: '云开发未开通',
            content: '请在微信开发者工具中开通云开发服务并创建云环境，然后在app.js中配置正确的环境ID。',
            showCancel: false
          });
        } else {
          wx.showToast({
            title: '图片上传失败',
            icon: 'none'
          });
        }
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})