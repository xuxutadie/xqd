// pages/works/works.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    filterIndex: 0,
    filters: ['全部作品', '最新上传', '最早上传'],
    works: [
      {
        id: 1,
        title: '星空下的梦想',
        category: '图片',
        date: '2023-06-15',
        description: '这是一幅表达孩子梦想的画作，星空下的孩子充满了无限可能。',
        imageUrl: '/assets/work1.png'
      },
      {
        id: 2,
        title: '海洋世界',
        category: '图片',
        date: '2023-06-10',
        description: '这是一幅描绘海洋世界的画作，展示了孩子对海洋生物的想象。',
        imageUrl: '/assets/work2.png'
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.getWorks();
  },
  
  // 获取作品列表
  getWorks() {
    wx.showLoading({
      title: '加载中...'
    });
    
    // 调用云函数获取作品列表
    wx.cloud.callFunction({
      name: 'getWorks',
      data: {
        filter: this.data.filterIndex === 1 ? 'latest' : this.data.filterIndex === 2 ? 'oldest' : ''
      },
      success: res => {
        const { code, data } = res.result;
        
        if (code === 200 && data) {
          // 处理日期格式
          const works = data.map(item => {
            return {
              id: item._id,
              title: item.title,
              category: item.category,
              date: new Date(item.createTime).toLocaleDateString(),
              description: item.description || '',
              imageUrl: item.fileID
            };
          });
          
          this.setData({ works });
        } else {
          this.setData({ works: [] });
        }
        
        wx.hideLoading();
      },
      fail: err => {
        console.error('获取作品列表失败', err);
        wx.hideLoading();
        wx.showToast({
          title: '获取作品列表失败',
          icon: 'none'
        });
      }
    });
  },
  
  // 筛选变化
  bindFilterChange(e) {
    const filterIndex = e.detail.value;
    this.setData({ filterIndex }, () => {
      // 重新获取作品列表
      this.getWorks();
    });
  },
  
  // 编辑作品
  editWork(e) {
    const id = e.currentTarget.dataset.id;
    wx.showToast({
      title: '编辑功能开发中',
      icon: 'none'
    });
  },
  
  // 删除作品
  deleteWork(e) {
    const id = e.currentTarget.dataset.id;
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这个作品吗？',
      success: (res) => {
        if (res.confirm) {
          wx.showLoading({
            title: '删除中...'
          });
          
          // 检查云开发是否已初始化
          if (!wx.cloud) {
            wx.hideLoading();
            wx.showModal({
              title: '提示',
              content: '当前微信版本过低，无法使用云开发功能，请升级到最新微信版本后重试。',
              showCancel: false
            });
            return;
          }
          
          // 调用云函数删除作品
          wx.cloud.callFunction({
            name: 'deleteWork',
            data: {
              workId: id
            },
            success: result => {
              const { code, message } = result.result;
              
              wx.hideLoading();
              
              if (code === 200) {
                wx.showToast({
                  title: '删除成功',
                  icon: 'success'
                });
                
                // 重新获取作品列表
                this.getWorks();
              } else {
                wx.showToast({
                  title: message || '删除失败',
                  icon: 'none'
                });
              }
            },
            fail: err => {
              console.error('调用云函数失败', err);
              wx.hideLoading();
              wx.showModal({
                title: '云函数调用失败',
                content: '请确认云函数已正确部署，并且云环境已正确配置。',
                showCancel: false
              });
            }
          });
        }
      }
    });
  },
  
  // 跳转到上传页面
  navigateToUpload() {
    wx.navigateTo({
      url: '/pages/upload/upload'
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})