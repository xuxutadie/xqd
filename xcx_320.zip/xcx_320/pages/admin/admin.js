// pages/admin/admin.js
Page({
  data: {
    competitions: [],
    newCompetition: {
      title: '',
      image: '/assets/logo.png',
      description: '',
      deadline: '',
      status: '筹备中'
    },
    isEditing: false,
    currentEditId: null
  },

  onLoad: function() {
    // 检查用户是否是管理员
    this.checkAdminPermission();
    // 加载比赛数据
    this.loadCompetitions();
  },

  // 检查管理员权限
  checkAdminPermission: function() {
    const userInfo = wx.getStorageSync('userInfo');
    if (!userInfo || userInfo.role !== 'admin') {
      wx.showToast({
        title: '您没有管理员权限',
        icon: 'none'
      });
      setTimeout(() => {
        wx.switchTab({
          url: '/pages/index/index'
        });
      }, 1500);
    }
  },

  // 加载比赛数据
  loadCompetitions: function() {
    wx.showLoading({
      title: '加载中...'
    });
    
    // 调用云函数获取比赛数据
    wx.cloud.callFunction({
      name: 'manageCompetition',
      data: {
        action: 'get'
      }
    }).then(res => {
      wx.hideLoading();
      if (res.result.code === 200) {
        // 处理返回的数据，确保格式一致
        const competitions = res.result.data.map(item => ({
          id: item._id, // 使用数据库的_id作为id
          title: item.title,
          image: item.image || '/assets/logo.png',
          description: item.description,
          deadline: item.deadline,
          status: item.status
        }));
        this.setData({ competitions });
      } else {
        wx.showToast({
          title: res.result.message || '获取比赛数据失败',
          icon: 'none'
        });
      }
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({
        title: '获取比赛数据失败',
        icon: 'none'
      });
      console.error('获取比赛数据失败', err);
    });
  },

  // 输入比赛标题
  inputTitle: function(e) {
    this.setData({
      'newCompetition.title': e.detail.value
    });
  },

  // 输入比赛描述
  inputDescription: function(e) {
    this.setData({
      'newCompetition.description': e.detail.value
    });
  },

  // 输入截止日期
  inputDeadline: function(e) {
    this.setData({
      'newCompetition.deadline': e.detail.value
    });
  },

  // 选择状态
  bindStatusChange: function(e) {
    const statuses = ['筹备中', '报名中', '即将开始', '已结束'];
    this.setData({
      'newCompetition.status': statuses[e.detail.value]
    });
  },

  // 添加新比赛
  addCompetition: function() {
    const { title, description, deadline, status, image } = this.data.newCompetition;
    if (!title || !description || !deadline) {
      wx.showToast({
        title: '请填写完整信息',
        icon: 'none'
      });
      return;
    }

    wx.showLoading({
      title: this.data.isEditing ? '更新中...' : '添加中...'
    });
    
    // 调用云函数添加或更新比赛
    wx.cloud.callFunction({
      name: 'manageCompetition',
      data: {
        action: this.data.isEditing ? 'update' : 'add',
        competition: {
          title,
          description,
          deadline,
          status,
          image: image || '/assets/logo.png'
        },
        id: this.data.isEditing ? this.data.currentEditId : null
      }
    }).then(res => {
      wx.hideLoading();
      if (res.result.code === 200) {
        // 重新加载比赛数据
        this.loadCompetitions();
        
        // 重置表单
        this.setData({
          isEditing: false,
          currentEditId: null,
          newCompetition: {
            title: '',
            image: '/assets/logo.png',
            description: '',
            deadline: '',
            status: '筹备中'
          }
        });
        
        wx.showToast({
          title: this.data.isEditing ? '编辑成功' : '添加成功',
          icon: 'success'
        });
      } else {
        wx.showToast({
          title: res.result.message || '操作失败',
          icon: 'none'
        });
      }
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({
        title: '操作失败',
        icon: 'none'
      });
      console.error('比赛操作失败', err);
    });
  },

  // 编辑比赛
  editCompetition: function(e) {
    const id = e.currentTarget.dataset.id;
    const competition = this.data.competitions.find(c => c.id === id);
    if (competition) {
      this.setData({
        newCompetition: { ...competition },
        isEditing: true,
        currentEditId: id
      });
    }
  },

  // 删除比赛
  deleteCompetition: function(e) {
    const id = e.currentTarget.dataset.id;
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这个比赛吗？',
      success: res => {
        if (res.confirm) {
          wx.showLoading({
            title: '删除中...'
          });
          
          // 调用云函数删除比赛
          wx.cloud.callFunction({
            name: 'manageCompetition',
            data: {
              action: 'delete',
              id: id
            }
          }).then(res => {
            wx.hideLoading();
            if (res.result.code === 200) {
              // 重新加载比赛数据
              this.loadCompetitions();
              
              wx.showToast({
                title: '删除成功',
                icon: 'success'
              });
            } else {
              wx.showToast({
                title: res.result.message || '删除失败',
                icon: 'none'
              });
            }
          }).catch(err => {
            wx.hideLoading();
            wx.showToast({
              title: '删除失败',
              icon: 'none'
            });
            console.error('删除比赛失败', err);
          });
        }
      }
    });
  },

  // 返回首页
  navigateToHome:function() {
    wx.switchTab({
      url: '/pages/index/index'
    });
  }
})