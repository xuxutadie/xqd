Page({
  data: {
    userInfo: null
  },
  
  onLoad() {
    wx.login({
      success: (res) => {
        if (res.code) {
          // 获取用户信息
          wx.getUserProfile({
            desc: '用于完善用户资料',
            success: (result) => {
              this.setData({
                userInfo: result.userInfo
              })
              wx.setStorageSync('userInfo', result.userInfo)
              wx.navigateTo({
                url: '/pages/index/index'
              })
            }
          })
        }
      }
    })
  }
})
