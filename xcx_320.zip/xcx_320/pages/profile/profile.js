Page({
  data: {
    userInfo: {
      nickname: '用户昵称',
      userId: '123456',
      avatar: '/images/default-avatar.png'
    },
    stats: {
      follows: 0,
      fans: 0,
      likes: 0
    }
  },

  onLoad: function() {
    // 页面加载时获取用户信息
    this.getUserInfo()
  },

  getUserInfo: function() {
    // 这里可以调用获取用户信息的API
    // 目前使用模拟数据
  },

  onMenuItemTap: function(e) {
    const type = e.currentTarget.dataset.type
    switch(type) {
      case 'favorite':
        wx.navigateTo({
          url: '/pages/favorite/favorite'
        })
        break
      case 'history':
        wx.navigateTo({
          url: '/pages/history/history'
        })
        break
      case 'settings':
        wx.navigateTo({
          url: '/pages/settings/settings'
        })
        break
    }
  }
})