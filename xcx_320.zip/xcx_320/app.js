App({
  onLaunch: function() {
    // 小程序初始化时执行，全局只执行一次
    
    // 初始化云环境
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力');
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用云开发功能，请升级到最新微信版本后重试。',
        showCancel: false
      });
    } else {
      try {
        wx.cloud.init({
          env: 'prod-5go6u25pcb38f3f0', // 替换为你的云环境ID
          traceUser: true,
        });
      } catch (error) {
        console.error('云环境初始化失败', error);
        wx.showModal({
          title: '云开发未开通',
          content: '请在微信开发者工具中开通云开发服务并创建云环境，然后在app.js中配置正确的环境ID。',
          showCancel: false
        });
      }
    }
  },
  onShow: function(options) {
    // 小程序启动，或从后台进入前台显示时执行
  },
  onHide: function() {
    // 小程序从前台进入后台时执行
  },
  globalData: {
    // 全局数据
  }
})