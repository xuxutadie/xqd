// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

// 云函数入口函数
exports.main = async (event, context) => {
  const { title, description, category, fileID } = event
  const wxContext = cloud.getWXContext()
  
  if (!title || !fileID) {
    return {
      code: 400,
      message: '标题和文件不能为空'
    }
  }
  
  try {
    // 获取用户信息
    const userResult = await db.collection('users').where({
      openid: wxContext.OPENID
    }).get()
    
    // 如果用户不存在，返回错误
    if (userResult.data.length === 0) {
      return {
        code: 401,
        message: '用户未登录或不存在'
      }
    }
    
    // 添加作品到数据库
    const result = await db.collection('works').add({
      data: {
        title,
        description: description || '',
        category,
        fileID,
        createTime: db.serverDate(),
        creator: wxContext.OPENID,
        username: userResult.data[0].username
      }
    })
    
    return {
      code: 200,
      message: '上传成功',
      data: {
        _id: result._id
      }
    }
  } catch (err) {
    return {
      code: 500,
      message: '服务器错误',
      error: err
    }
  }
}