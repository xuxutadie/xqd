// 云函数入口文件
const cloud = require('wx-server-sdk')
const crypto = require('crypto')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

// 加密密码
function encryptPassword(password) {
  return crypto.createHash('sha256').update(password).digest('hex')
}

// 云函数入口函数
exports.main = async (event, context) => {
  const { username, password, openid, isRegister } = event
  const wxContext = cloud.getWXContext()
  
  if (!username || !password) {
    return {
      code: 400,
      message: '用户名和密码不能为空'
    }
  }
  
  try {
    // 加密密码
    const encryptedPassword = encryptPassword(password)
    
    // 查询用户是否存在
    const userResult = await db.collection('users').where({
      username: username
    }).get()
    
    // 检查用户是否存在
    if (userResult.data.length === 0) {
      // 检查是否是管理员账号
      let role = 'user'
      if (username === 'admin' && password === 'admin123') {
        role = 'admin'
      }
      
      // 创建新用户
      const result = await db.collection('users').add({
        data: {
          username,
          password: encryptedPassword,
          role,
          openid: wxContext.OPENID || openid,
          createTime: db.serverDate(),
          lastLoginTime: db.serverDate()
        }
      })
      
      return {
        code: 200,
        message: '注册成功并登录',
        data: {
          username,
          role,
          openid: wxContext.OPENID || openid
        }
      }
    }
    
    // 如果是注册请求且用户已存在，返回错误
    if (isRegister && userResult.data.length > 0) {
      return {
        code: 409,
        message: '用户名已存在，请更换用户名或直接登录'
      }
    }
    
    // 用户存在，验证密码
    const user = userResult.data[0]
    
    // 如果数据库中的密码未加密（旧用户），则直接比较，否则比较加密后的密码
    let passwordCorrect = false
    if (user.password.length < 32) { // 未加密的密码通常较短
      passwordCorrect = user.password === password
      // 如果密码正确，更新为加密密码
      if (passwordCorrect) {
        await db.collection('users').doc(user._id).update({
          data: {
            password: encryptedPassword
          }
        })
      }
    } else {
      passwordCorrect = user.password === encryptedPassword
    }
    
    if (!passwordCorrect) {
      return {
        code: 401,
        message: '密码错误'
      }
    }
    
    // 更新用户的登录时间和openid（如果有变化）
    await db.collection('users').doc(user._id).update({
      data: {
        lastLoginTime: db.serverDate(),
        openid: wxContext.OPENID || openid || user.openid
      }
    })
    
    return {
      code: 200,
      message: '登录成功',
      data: {
        username: user.username,
        role: user.role,
        openid: wxContext.OPENID || openid || user.openid
      }
    }
  } catch (err) {
    return {
      code: 500,
      message: '服务器错误',
      error: err
    }
  }
}