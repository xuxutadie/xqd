// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

// 云函数入口函数
exports.main = async (event, context) => {
  const { workId } = event
  const wxContext = cloud.getWXContext()
  
  if (!workId) {
    return {
      code: 400,
      message: '作品ID不能为空'
    }
  }
  
  try {
    // 获取作品信息，确认是否为作者本人
    const workResult = await db.collection('works').doc(workId).get()
    
    if (workResult.data.length === 0) {
      return {
        code: 404,
        message: '作品不存在'
      }
    }
    
    const work = workResult.data
    
    // 检查是否为作者本人或管理员
    const userResult = await db.collection('users').where({
      openid: wxContext.OPENID
    }).get()
    
    if (userResult.data.length === 0) {
      return {
        code: 401,
        message: '用户未登录'
      }
    }
    
    const user = userResult.data[0]
    
    // 只有作者本人或管理员可以删除作品
    if (work.creator !== wxContext.OPENID && user.role !== 'admin') {
      return {
        code: 403,
        message: '没有权限删除该作品'
      }
    }
    
    // 删除云存储中的文件
    await cloud.deleteFile({
      fileList: [work.fileID]
    })
    
    // 删除数据库中的记录
    await db.collection('works').doc(workId).remove()
    
    return {
      code: 200,
      message: '删除成功'
    }
  } catch (err) {
    return {
      code: 500,
      message: '服务器错误',
      error: err
    }
  }
}