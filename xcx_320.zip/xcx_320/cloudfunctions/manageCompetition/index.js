// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

// 云函数入口函数
exports.main = async (event, context) => {
  const { action, competition, id } = event
  const wxContext = cloud.getWXContext()
  
  try {
    // 验证用户是否为管理员
    const userResult = await db.collection('users').where({
      openid: wxContext.OPENID
    }).get()
    
    if (userResult.data.length === 0 || userResult.data[0].role !== 'admin') {
      return {
        code: 403,
        message: '没有管理员权限'
      }
    }
    
    // 根据不同操作执行不同逻辑
    if (action === 'add') {
      // 添加比赛
      if (!competition || !competition.title || !competition.description || !competition.deadline) {
        return {
          code: 400,
          message: '比赛信息不完整'
        }
      }
      
      const result = await db.collection('competitions').add({
        data: {
          ...competition,
          createTime: db.serverDate(),
          creator: wxContext.OPENID
        }
      })
      
      return {
        code: 200,
        message: '添加成功',
        data: {
          _id: result._id
        }
      }
    } else if (action === 'update') {
      // 更新比赛
      if (!id || !competition) {
        return {
          code: 400,
          message: '参数不完整'
        }
      }
      
      await db.collection('competitions').doc(id).update({
        data: {
          ...competition,
          updateTime: db.serverDate()
        }
      })
      
      return {
        code: 200,
        message: '更新成功'
      }
    } else if (action === 'delete') {
      // 删除比赛
      if (!id) {
        return {
          code: 400,
          message: 'ID不能为空'
        }
      }
      
      await db.collection('competitions').doc(id).remove()
      
      return {
        code: 200,
        message: '删除成功'
      }
    } else if (action === 'get') {
      // 获取比赛列表
      const competitions = await db.collection('competitions').get()
      
      return {
        code: 200,
        data: competitions.data
      }
    } else {
      return {
        code: 400,
        message: '不支持的操作'
      }
    }
  } catch (err) {
    return {
      code: 500,
      message: '服务器错误',
      error: err
    }
  }
}