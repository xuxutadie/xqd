// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const MAX_LIMIT = 100

// 云函数入口函数
exports.main = async (event, context) => {
  const { filter } = event
  
  try {
    // 获取总数
    const countResult = await db.collection('works').count()
    const total = countResult.total
    
    // 计算需要分几次取
    const batchTimes = Math.ceil(total / MAX_LIMIT)
    
    // 承载所有读操作的 promise 的数组
    const tasks = []
    
    for (let i = 0; i < batchTimes; i++) {
      const promise = db.collection('works')
        .skip(i * MAX_LIMIT)
        .limit(MAX_LIMIT)
        .get()
      
      tasks.push(promise)
    }
    
    // 等待所有
    const results = await Promise.all(tasks)
    
    // 拼接结果
    let works = []
    results.forEach(result => {
      works = works.concat(result.data)
    })
    
    // 根据筛选条件排序
    if (filter === 'latest') {
      // 最新上传
      works.sort((a, b) => b.createTime - a.createTime)
    } else if (filter === 'oldest') {
      // 最早上传
      works.sort((a, b) => a.createTime - b.createTime)
    }
    
    return {
      code: 200,
      data: works,
      total
    }
  } catch (err) {
    return {
      code: 500,
      message: '获取作品列表失败',
      error: err
    }
  }
}